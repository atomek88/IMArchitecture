package com.company;

/**
 * Created by tomaszmichalik on 5/28/17.
 */
public class UserFactory {
}
