Notes:

decouple stupid ui panel and user object into one or create a userPanel with a user inside